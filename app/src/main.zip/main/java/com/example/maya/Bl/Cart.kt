package com.example.maya.Bl

data class Cart(
    var productImage:Int,
    var productName: String = "",
    var productId: String = "",
    var productPrice: String = "",
    var productQuantity: Int = 0
)
